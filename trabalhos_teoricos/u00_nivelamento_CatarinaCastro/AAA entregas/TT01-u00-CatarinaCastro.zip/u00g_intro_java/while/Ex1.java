/*
Unidade 00 - Nivelamento
Introdução ao Java

Catarina F. M. Castro - 803531

AEDs II
*/

// Mostra os 10 primeiros números inteiros positivos

import java.util.*;
import java.io.*;

public class Ex1 {
    public static void main(String[] args){
        int num = 1;

        while(num < 11){
            System.out.println(num);
            num++;
        }

    }
}
