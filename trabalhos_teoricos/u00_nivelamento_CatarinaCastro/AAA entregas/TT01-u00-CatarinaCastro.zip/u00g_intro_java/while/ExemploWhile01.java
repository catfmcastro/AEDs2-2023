/*
Unidade 00 - Nivelamento
Introdução ao Java

Catarina F. M. Castro - 803531

AEDs II
*/

// Mostre na tela os 10 primeiros números pares

import java.util.*;
import java.io.*;

public class ExemploWhile01{
    public static void main(String[] args){
        int num = 2;

        while(num < 21){
            System.out.println(num);
            num+=2;
        }

    }
}